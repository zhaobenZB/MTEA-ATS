classdef MTEA_ATS4 < Algorithm
% <Multi-task/Many-task> <Single-objective/Multi-objective> <None>

properties (SetAccess = private)
    P = 0.1
    H = 100
    Operator = 'GA/DE';
    mu = 2;
    mum = 5;
end

methods
    function Parameter = getParameter(Algo)
        Parameter = {'P: 100p% top as pbest', num2str(Algo.P), ...
                'H: success memory size', num2str(Algo.H),...
                'Operator (Split with /)', Algo.Operator,...
                'mu: index of Simulated Binary Crossover', num2str(Algo.mu), ...
                'mum: index of polynomial mutation', num2str(Algo.mum)};
    end

    function Algo = setParameter(Algo, Parameter)
        i = 1;
        Algo.P = str2double(Parameter{i}); i = i + 1;
        Algo.H = str2double(Parameter{i}); i = i + 1;
        Algo.Operator = Parameter{i}; i = i + 1;
        Algo.mu = str2double(Parameter{i}); i = i + 1;
        Algo.mum = str2double(Parameter{i}); i = i + 1;
    end

    function run(Algo, Prob)
        operator = split(Algo.Operator, '/');
        % Initialization
        population = Initialization_MT(Algo, Prob, Individual_DE);
        for t = 1:Prob.T
            if max(Prob.M)>1
                rank = NSGA2Sort(population{t});
            else
                [~, rank] = sortrows([population{t}.CVs, population{t}.Objs], [1, 2]);
            end
            population{t} = population{t}(rank);
        end
        for t = 1:Prob.T
            % initialize Parameter
            Hidx{t} = 1;
            MF{t} = 0.5 .* ones(Algo.H, 1);
            MCR{t} = 0.5 .* ones(Algo.H, 1);
            archive{t} = Individual_DE.empty();
        end
        scale=ones(Prob.T,Prob.T)*0.5; % adjust nTransfer dynamically
        trans=ones(1,Prob.T)*0.5;
        table=ones(Prob.T,Prob.T)*0.5;
        table1=zeros(Prob.T,Prob.T);
        PKTS=ones(2,Prob.T)*0.5;
        for t=1:Prob.T
            table(t,t)=0;
        end
        pkts=0.5;
        while Algo.notTerminated(Prob,population)
            for t = 1:Prob.T
                m_l=table(t,:);
                m_l(m_l==0)=[];
                if max(m_l)==min(m_l)
                    l=ones(1,Prob.T)*0.5;
                    l(t)=0;
                else
                    for i=1:Prob.T
                        if i==t
                            l(i)=0;
                        else
                            l(i)=(table(t,i)-min(m_l))/(max(table(t,:))-min(m_l))*(0.9-0.1)+0.1;
                        end
                    end
                end
                m_pt=select_task(l);
                option=select_task([scale(t,m_pt),0,trans(t)]);%OK
                if option~=1
                    m_pt=t;
                end
                if option==3
                    tempPopulation=population{t};
                    sign=2;
                else
                    if option~=3  && rand<pkts
                        sign=1;
                        nTransfer=Prob.N;%round(scale(t,m_pt)*Prob.N);
                    else
                        sign=2;
                        nTransfer=round(scale(t,m_pt)*Prob.N);
                    end
                    tempPopulation=population{t}(end:-1:1);                    
                    [~,order]=varOrder2(population{m_pt},population{t},Prob.D(m_pt),Prob.D(t),option);
                    tempPopulation(1:nTransfer)=m_transfer11(population{m_pt},population{t},Prob.D(m_pt),Prob.D(t),nTransfer,order,option);
                end

                if sign==1 
                    for i = 1:length(tempPopulation)
%                         idx = randi(Algo.H);
%                         uCR = MCR{t}(idx);
%                         CR = normrnd(uCR, 0.1);
%                         CR(CR > 1) = 1;
%                         CR(CR < 0) = 0;
                        CR=0.5;
%                         CR=0.1+rand*(0.9-0.1);
                        offspring(i) = population{t}(i);
                        r1 = randi(length(tempPopulation));
                        offspring(i).Dec = DE_Crossover(offspring(i).Dec, tempPopulation(r1).Dec,CR);
                    end
                    % Evaluation
                    offspring = Algo.Evaluation(offspring, Prob, t);
                    % Selection
%                     [~, replace] = Selection_Tournament(population{t}, offspring);
                    
                else
                % Calculate individual F and CR
                for i = 1:length(population{t})
%                     idx = randi(Algo.H);
%                     uF = MF{t}(idx);
%                     tempPopulation(i).F = uF + 0.1 * tan(pi * (rand() - 0.5));
%                     while (tempPopulation(i).F <= 0)
%                         tempPopulation(i).F = uF + 0.1 * tan(pi * (rand() - 0.5));
%                     end
%                     tempPopulation(i).F(tempPopulation(i).F > 1) = 1;
%                     uCR = MCR{t}(idx);
%                     tempPopulation(i).CR = normrnd(uCR, 0.1);
%                     tempPopulation(i).CR(tempPopulation(i).CR > 1) = 1;
%                     tempPopulation(i).CR(tempPopulation(i).CR < 0) = 0;
                    tempPopulation(i).F=0.5;
                    tempPopulation(i).CR =0.5;
%                     tempPopulation(i).F=0.1+rand*(2-0.1);
%                     tempPopulation(i).CR =0.1+rand*(0.9-0.1);
                end

                % Generation
%                 union = [population{t}, archive{t}];
%                 offspring = Algo.Generation(tempPopulation, union, population{t});
%                 offspring = Algo.Generation_DE(tempPopulation);
                % Generation
                op_idx = mod(t - 1, length(operator)) + 1;
                op = operator{op_idx};
                switch op
                    case 'GA'
                        offspring = Algo.Generation_GA(tempPopulation);
                    case 'DE'
                        offspring = Algo.Generation_DE(tempPopulation);
                end
                % Evaluation
                offspring = Algo.Evaluation(offspring, Prob, t);
                % Selection
%                 [~, replace] = Selection_Tournament(population{t}, offspring);

                % calculate SF SCR
%                 SF = [tempPopulation(replace).F];
%                 SCR = [tempPopulation(replace).CR];
%                 dif = population{t}(replace).CVs' - offspring(replace).CVs';
%                 dif_obj = population{t}(replace).Objs' - offspring(replace).Objs';
%                 dif_obj(dif_obj < 0) = 0;
%                 dif(dif <= 0) = dif_obj(dif <= 0);
%                 dif = dif ./ sum(dif);
%                 % update MF MCR
%                 if ~isempty(SF)
%                     MF{t}(Hidx{t}) = sum(dif .* (SF.^2)) / sum(dif .* SF);
%                     MCR{t}(Hidx{t}) = sum(dif .* SCR);
%                 else
%                     MF{t}(Hidx{t}) = MF{t}(mod(Hidx{t} + Algo.H - 2, Algo.H) + 1);
%                     MCR{t}(Hidx{t}) = MCR{t}(mod(Hidx{t} + Algo.H - 2, Algo.H) + 1);
%                 end
%                 Hidx{t} = mod(Hidx{t}, Algo.H) + 1;
                end
                % Update archive
%                 archive{t} = [archive{t}, population{t}(replace)];
%                 if length(archive{t}) > length(population{t})
%                     archive{t} = archive{t}(randperm(length(archive{t}), length(population{t})));
%                 end
%                 population{t}(replace) = offspring(replace);
                if max(Prob.M)==1
                    [~, rank] = Selection_Elit(population{t}, offspring);
                else
                    rank = NSGA2Sort([population{t},offspring]);
                end
                temp=[population{t}, offspring];
                population{t}=temp(rank(1:Prob.N));
%                 [~,rank] = sortrows([population{t}.CVs, population{t}.Objs], [1, 2]);
%                 population{t}=population{t}(rank);
                pop=population{t}(end:-1:1);

                [~,ia]=intersect(pop.Decs,offspring.Decs,'rows');
                temp = 0.1+sum(ia)/(Prob.N/2*(Prob.N+1))*(0.5-0.1);

                if option==3
                    trans(t)=temp;
                else
                    scale(t,m_pt)=temp;
%                     PKTS(sign,t)=(PKTS(sign,t)+scale(t,m_pt))/2;
                end
                if option~=3
                    temp=(scale(t,m_pt)-trans(t))/(scale(t,m_pt)+trans(t));
                    PKTS(sign,t)=temp;
%                     PKTS(sign,t)=(PKTS(sign,t)+temp)/2;
                    pkts=PKTS(1,t)/(PKTS(1,t)+PKTS(2,t));
                    if PKTS(1,t)<0 && PKTS(2,t)<0
                        pkts=1-pkts;
                    else
                        if pkts<0.1 ||PKTS(2,t)<0 ||isnan(pkts);pkts=0.1;end
                        if pkts>0.9 ||PKTS(1,t)<0;pkts=0.9;end
                    end
                end
                if option==1
                    w=0.1+rand*(0.9-0.1);%PKTS(sign,t)/trans(t);%1-PKTS(3,t)/sum(PKTS(:,t));%0.3;%
%                     if w>0.9; w=0.9;end
%                     if w<0.1; w=0.1;end
                    table(t,m_pt)=0.5+w*(table(t,m_pt)-0.5)+(1-w)*temp*0.4;
%                     table(t,m_pt)=0.5+(table(t,m_pt)-0.5+temp*0.4)/2;
                    if table(t,m_pt)<0.1 || isnan(table(t,m_pt))
                        table(t,m_pt)=0.1;
                    end
                    if table(t,m_pt)>0.9
                        table(t,m_pt)=0.9;
                    end
                end
            end
%             disp(table1)
%             disp(scale)
%             disp(table)
%             disp('a:')
%             disp(PKTS)
        end
    end

    function offspring = Generation(Algo, population, union, pop)
        % get top 100p% individuals
        [~, rank] = sortrows([pop.CVs, pop.Objs], [1, 2]);
        pop_pbest = rank(1:max(round(Algo.P * length(pop)), 1));
%         pop_pbest =[1:max(round(Algo.P * length(population)), 1)];
        for i = 1:length(population)
            offspring(i) = population(i);
            pbest = pop_pbest(randi(length(pop_pbest)));
            x1 = randi(length(population));
            while x1 == i || x1 == pbest
                x1 = randi(length(population));
            end
            x2 = randi(length(union));
            while x2 == i || x2 == x1 || x2 == pbest
                x2 = randi(length(union));
            end

            offspring(i).Dec = population(i).Dec + ...
                population(i).F * (pop(pbest).Dec - population(i).Dec) + ...
                population(i).F * (population(x1).Dec - union(x2).Dec);
            offspring(i).Dec = DE_Crossover(offspring(i).Dec, population(i).Dec, population(i).CR);

            % offspring(i).Dec(offspring(i).Dec > 1) = 1;
            % offspring(i).Dec(offspring(i).Dec < 0) = 0;

            vio_low = find(offspring(i).Dec < 0);
            offspring(i).Dec(vio_low) = (population(i).Dec(vio_low) + 0) / 2;
            vio_up = find(offspring(i).Dec > 1);
            offspring(i).Dec(vio_up) = (population(i).Dec(vio_up) + 1) / 2;
        end
    end
    
    function offspring = Generation_DE(Algo, population)
        for i = 1:length(population)
            %                 xbest=population(end-round(rand*length(population)*0.2));
            offspring(i) = population(i);
            A = randperm(length(population), 4);
            A(A == i) = []; x1 = A(1); x2 = A(2); x3 = A(3);
            %                 offspring(i).Dec = population(i).Dec + population(i).F * (xbest.Dec-population(i).Dec+population(x2).Dec - population(x3).Dec);
            offspring(i).Dec = population(x1).Dec + population(i).F * (population(x2).Dec - population(x3).Dec);
            offspring(i).Dec = DE_Crossover(offspring(i).Dec, population(i).Dec, population(i).CR);
            
            rand_Dec = rand(1, length(offspring(i).Dec));
            offspring(i).Dec(offspring(i).Dec > 1) = rand_Dec(offspring(i).Dec > 1);
            offspring(i).Dec(offspring(i).Dec < 0) = rand_Dec(offspring(i).Dec < 0);
        end
    end

    function offspring = Generation_GA(Algo, population)
        indorder = randperm(length(population));
        count = 1;
        for i = 1:ceil(length(population) / 2)
            p1 = indorder(i);
            p2 = indorder(i + fix(length(population) / 2));
            offspring(count) = population(p1);
            offspring(count + 1) = population(p2);
            
            [offspring(count).Dec, offspring(count + 1).Dec] = GA_Crossover(population(p1).Dec, population(p2).Dec, Algo.mu);
            
            offspring(count).Dec = GA_Mutation(offspring(count).Dec, Algo.mum);
            offspring(count + 1).Dec = GA_Mutation(offspring(count + 1).Dec, Algo.mum);
            
            for x = count:count + 1
                offspring(x).Dec(offspring(x).Dec > 1) = 1;
                offspring(x).Dec(offspring(x).Dec < 0) = 0;
            end
            count = count + 2;
        end
    end

end
end
